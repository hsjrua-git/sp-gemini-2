# Comprehensive Audit Remediation & Architectural Enhancement Plan

This plan resolves every critical, major, minor, and cosmetic issue identified during the four-pass audit alongside all six architectural suggestions. Every logical stage will be committed as an atomic, self-contained Git commit so you can inspect or roll back any individual step at any time.

---

## User Review & Confirmed Decisions

> [!IMPORTANT]
> The following decisions from your responses are locked into this plan:

- **Step-by-Step Atomic Git Commits**: All changes will be grouped into clean, incremental commits (database & migrations, backend security & validation, backend logic & scripts, voice agent & kiosk, frontend functional fixes, frontend layout/RTL/accessibility, and test/doc updates) with verification run between stages.
- **Database Integrity via Forward Migration**: A new forward migration will enforce non-overlapping fiscal periods and non-null evaluation lock timestamps on session-backed rows while preserving the exact existing schema design and compatibility with both PostgreSQL and embedded PGlite.
- **Full Data Reset & Re-Seeding**: The data reset workflow will cleanly wipe all runtime domain tables (students, groups, schedule/sessions/tasks/alerts, evaluations, cafe inventory/sales/balances, and accounting journals) and restore the required baseline seeded state (roles, permissions, chart of accounts, cafe-to-journal mappings, and administrator account).
- **Safe Removal of Legacy Settings View**: After confirming no active routes or components depend on the deprecated global period-anchor view, the unused legacy component and its orphaned translation namespace will be removed.

---

## 1. Overview & Core Concept

- **What It Does**: Restores full end-to-end reliability across student evaluation, group scoring, scheduling, cafe POS/balances, accrual accounting, on-device PGlite services, and the bilingual Persian/English voice kiosk.
- **Target Audience / Persona**: School administrators, teachers, evaluators (including blind-entry and staff roles), accountants, and cafe kiosk operators working in Persian (RTL) and English (LTR).
- **Key Value**: Eliminates silent data-entry failures, closes privilege escalation and XSS vectors, brings on-device PGlite services and reset/verification scripts into 100% alignment with the current schema, and fixes RTL layout and keyboard accessibility across all views.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  - **Evaluation Flow**: Selecting a group assignment on the evaluation screen immediately loads both the whole-group row and every active group member row; saving scores on the default session works immediately without requiring a redundant dropdown switch; server-side per-row validation messages update the affected row in place.
  - **Group Membership Flow**: Staff users with group-assignment permissions can open the groups workspace to assign and remove group members, while group creation/deletion controls remain restricted to group managers.
  - **Sessions & Scheduling Flow**: The sessions table accurately displays each session's period sequence number even when filtered by date or status, and task templates persist their linked parameter and extra configuration fields.
  - **Audit & Accounting Flow**: All 23 backend audit categories can be filtered and read with localized Persian and English descriptions; accounting account and fiscal period tables show row-scoped error alerts rather than repeating banners in every row.
- **Visual Identity & Theme**:
  - **Aesthetic Direction**: Utilitarian, high-density bilingual educational & financial workspace with zero visual clutter.
  - **Color Palette & Mood**: Preserves the existing token-driven light and dark theme system (`--bg`, `--surface`, `--border`, `--text`, `--accent`, `--danger`) with semantic status contrast.
  - **Typography & Hierarchy**: Vazirmatn for Persian (`[lang="fa"]`) and Manrope (`--font-numeric` with `tabular-nums`) for aligned numeric tables, scores, and Toman ledger figures.
  - **Component Styling & Layout**: Full logical CSS property discipline (`margin-inline-start`, `padding-inline-start`, `border-inline-start`, `inset-inline-end`) so tree indentation, active row indicators, account menus, segmented controls, and drawers mirror accurately between RTL (Persian) and LTR (English). All data tables across all 12 previously unwrapped pages gain responsive `.table-wrap` scroll containers.
- **Interactive Feedback & Motion**:
  - Slide-over drawers trap keyboard focus reliably even when empty and restore focus on close; top navigation displays the active page title across all routes and marks `aria-current="page"` without prefix collisions; the cohort constellation clears stale tooltips when filtered and supports keyboard selection.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Database-Enforced Fiscal Period Non-Overlap via Trigger vs. GIST Extension**
  - *Chosen Approach*: Enforce non-overlapping fiscal periods (`acct_periods`) using a `BEFORE INSERT OR UPDATE` trigger function alongside deterministic ordering (`ORDER BY starts_on DESC LIMIT 1`) in `acct_entries_guard()`, plus a `CHECK (session_id IS NULL OR locks_at IS NOT NULL)` constraint on `evaluations`.
  - *Why*: Standard PostgreSQL `EXCLUDE USING gist` on integer/date ranges requires `CREATE EXTENSION btree_gist`, which may require superuser privileges on managed/LAN Postgres setups and is not bundled in all embedded PGlite builds. A trigger + serialized transaction check works identically in both PostgreSQL and PGlite without superuser extensions.
  - *Alternatives Considered*: `btree_gist` exclusion constraint (rejected due to superuser/PGlite extension portability risk).

- **Decision 2: Shared Service Layer Alignment for On-Device PGlite**
  - *Chosen Approach*: Update the PGlite core services (`students`, `groups`, `export`) to use Web Crypto (`core/crypto.js`), respect `left_on IS NULL` soft-membership history, support all student demographic columns (`gender`, `birth_date`, `father_name`, `national_id`), restrict `extra` field writes by permission, and record audit entries.
  - *Why*: Keeps browser/Capacitor offline builds behaviorally identical to the Express API without breaking browser bundling on `node:crypto`.

- **Decision 3: Voice Agent Resilient Auto-LLM Detection & Local Kiosk Hardening**
  - *Chosen Approach*: Probe Ollama readiness with a fast timeout and automatically fall back to the deterministic bilingual intent parser whenever the LLM is unreachable; bind the kiosk HTTP server to `127.0.0.1` by default, validate `Origin` on control POSTs, escape HTML in cart rendering, and record both user and agent turns with `voice:` sale audit metadata.
  - *Why*: Ensures the voice agent works out of the box with zero external dependencies while preventing LAN/cross-origin abuse.

---

## 4. Technical Architecture & Commit Sequence

```
┌────────────────────────────────────────────────────────────────────────────┐
│                        Incremental Git Commit Plan                         │
├────────────────────────────────────────────────────────────────────────────┤
│ Commit 1: Database Migration (030), PGlite Verification & Reset Script     │
│   ├── Forward migration: acct_periods overlap trigger & evaluations check  │
│   ├── Fix verifyPglite seeded role count (5) & student_groups code insert  │
│   └── Fix resetData to wipe all runtime tables & preserve seeded baseline  │
├────────────────────────────────────────────────────────────────────────────┤
│ Commit 2: Backend Security, AuthZ Policies & Input Validation Hardening    │
│   ├── Require cafe.balance on POST /api/cafe/balances                      │
│   ├── Guard restricted custom student fields on POST/PATCH /api/students   │
│   ├── Allow scores.enter / students.view to read GET /api/groups/:id/members│
│   ├── Safe cookie decoding in CSRF middleware (no URIError 500s)           │
│   └── Uniform object guards across all validation parsers + 400/409 codes  │
├────────────────────────────────────────────────────────────────────────────┤
│ Commit 3: Backend Domain Logic, Transactions & On-Device Core Services     │
│   ├── Fix exportCube active vs. archived parameter filter & unit test      │
│   ├── Fix 10-digit national_id exact match in students & teachers search   │
│   ├── Fix session periodSeq calculation across filtered/single queries     │
│   ├── Persist parameterId & extra in taskTemplates route                   │
│   ├── Wrap session PATCH & accountingPeriods overlap check in transactions │
│   ├── Prevent multi-hop parent cycles in accountingAccounts PATCH          │
│   ├── Expand audit route categories (all 23 categories) & cafeSale note    │
│   └── Align core/services/{students,groups,export} with migration 029      │
├────────────────────────────────────────────────────────────────────────────┤
│ Commit 4: Voice Agent & Kiosk Reliability and Security                     │
│   ├── Fix agent CLI --file parsing & package.json Node 22 test script      │
│   ├── Fix Persian regex word boundaries, stripQty/stripFiller & debt sign  │
│   ├── Add Ollama health fallback in dialogue/llm & record user turns       │
│   └── Harden kiosk server (127.0.0.1 bind, Origin check, XSS fix, SSE turn)│
├────────────────────────────────────────────────────────────────────────────┤
│ Commit 5: Frontend Functional Fixes & State Management                     │
│   ├── Fix EvaluatePage group member array unwrapping & effectiveSessionId  │
│   ├── Fix EvaluationGrid rowsEqual memo check for general cell errors      │
│   ├── Fix SessionsPage periodSeq rendering & GroupsPage groups.assign gate │
│   ├── Scope row mutation errors on AccountingAccounts & AccountingPeriods  │
│   ├── Preserve error code/params in local.js & redirect state in LoginPage │
│   ├── Complete audit category filter & fa/en action translations           │
│   └── Remove dead SettingsPage & localize PreferencesProvider loading text │
├────────────────────────────────────────────────────────────────────────────┤
│ Commit 6: Frontend RTL Logical CSS, Responsive Tables & Accessibility      │
│   ├── Replace physical left/right CSS rules & inline paddingLeft with RTL  │
│   ├── Wrap all remaining tables across 12 pages in .table-wrap containers  │
│   ├── Fix Drawer focus trap, Layout topbar titles & mobile NavLink end     │
│   └── Fix CohortConstellation filtered hover cleanup & keyboard navigation │
├────────────────────────────────────────────────────────────────────────────┤
│ Commit 7: Test Suite Split, Integration Test Updates & Documentation Sync  │
│   ├── Split fast unit tests (test) vs PGlite core tests (test:core)        │
│   ├── Update permissions.test.js for post-029 endpoints & new unit tests   │
│   └── Sync CLAUDE.md, AGENTS.md, MOBILE.md, and setup.mjs error diagnostics│
└────────────────────────────────────────────────────────────────────────────┘
```

### Interactive Component & State Mapping
- **Evaluation Grid & Page**: Selecting a group assignment populates `members` directly from the array returned by `listGroupMembers`; clicking Save submits `effectiveSessionId` (`sessionId ?? defaultSessionId`); changing sessions preserves `effectiveAssignmentId`; server-side row validation errors trigger re-renders via `prevError?.general !== nextError?.general`.
- **Groups Management**: Users with `groups.assign` or `groups.manage` can access `/groups`; group-creation and group-deletion controls remain conditionally rendered for `groups.manage` while member assignment controls are active for `groups.assign`.
- **Voice Kiosk & Agent**: Spoken or typed utterances are recorded as `user` turns and broadcast over SSE `turn` events; if local Ollama is offline when `LLM_PROVIDER=auto`, the dialogue engine transparently falls back to deterministic Persian/English intent parsing without erroring out.
