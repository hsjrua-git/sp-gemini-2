# Repository Audit Notes (Problems & Suggestions)

Audited at commit `55d9e87` across `server/`, `client/`, `agent/`, `scripts/`, and `deploy/`.

---

## Verification Baseline

- **Server unit tests** (`npm --prefix server test`): **217 / 217 passing**
- **Server PGlite core service tests** (`npm --prefix server run test:core`): **54 / 54 passing**
- **Server PGlite migration & DB invariant verification** (`npm --prefix server run verify-pglite`): **30 migrations (`001`–`030`) & all invariants passing**
- **Client unit & component tests** (`npm --prefix client test`): **128 / 128 passing** (including `fa`/`en` i18n key-tree parity)
- **Client ESLint** (`npm --prefix client run lint`): **0 errors / 0 warnings**
- **Client production bundle** (`npm --prefix client run build`): **clean build to `client/dist`**
- **Agent test suite** (`npm --prefix agent test`): **61 / 61 passing**

---

## Problems (Ordered by Severity)

### 1. [Critical] Uncast PostgreSQL `date` columns (OID `1082`) deserialize as JavaScript `Date` objects, crashing `GET /api/sessions` on the server and `formatIsoDate` / `JalaliDatePicker` on the client

- **Where:**
  - `server/src/db/pool.js:10-16` & `server/src/db/pglite.js:61-66` (no OID `1082` type parser override)
  - `server/src/routes/sessions.js:18-20, 56` (`s.planned_date`, `s.moved_to`, `s.session_date` selected without `::text`)
  - `server/src/lib/periods.js:36` (`a.sessionDate.localeCompare(b.sessionDate)`)
  - `client/src/lib/locale.js:35-38` (`localDateFromIso(isoDate)`)
  - Additional uncast `date` selects in:
    - `server/src/routes/accountingPeriods.js:19-20, 105, 256` (`start_date`, `end_date`, `entry_date`)
    - `server/src/routes/accountingJournal.js:20` (`e.entry_date AS "entryDate"`)
    - `server/src/lib/accountingReports.js:54` (`e.entry_date AS "entryDate"`)
    - `server/src/routes/cafePurchases.js:22` (`pu.purchased_at AS "purchasedAt"`)
    - `server/src/lib/cafeReports.js:7` (`sold_at::date AS day`)
    - `server/src/routes/teachers.js:14` (`birth_date AS "birthDate"`)
    - `server/src/routes/assignments.js:25` (`a.anchor_date AS "anchorDate"`)
    - `server/src/routes/alerts.js:20` (`s.session_date AS "sessionDate"`)
- **Confirmed by:** Runtime execution of `pg` and `PGlite` date parsers + code trace.
- **Details:**
  1. Both `pg` and `@electric-sql/pglite` parse PostgreSQL `date` (OID `1082`) into JavaScript `Date` instances unless cast with `::text` in SQL or overridden via `setTypeParser(1082, ...)`.
  2. **Server crash (`GET /api/sessions`):** `withPeriodSeqs()` (`server/src/routes/sessions.js:56`) selects `session_date AS "sessionDate"` without `::text` and passes those rows to `assignPeriods()` (`server/src/lib/periods.js:36`), which calls `a.sessionDate.localeCompare(b.sessionDate)`. Because `sessionDate` is a `Date` instance, `localeCompare` is `undefined`, throwing `TypeError: a.sessionDate.localeCompare is not a function` (HTTP 500) whenever two or more sessions exist for an assignment.
  3. **Client crash (`RangeError: Invalid time value`):** When `Date` objects are serialized over JSON by Express, they become full ISO timestamps (`"2026-03-21T00:00:00.000Z"`). On the client, `localDateFromIso(isoDate)` (`client/src/lib/locale.js:35-38`) runs:
     ```js
     const [y, m, d] = isoDate.split('-').map(Number);
     ```
     With `"2026-03-21T00:00:00.000Z"`, `d` becomes `Number("21T00:00:00.000Z")` -> `NaN`, producing an `Invalid Date` and causing `Intl.DateTimeFormat(...).format(...)` to throw `RangeError: Invalid time value` (caught by `ErrorBoundary`) on `AccountingPeriodsPage` (immediately on load because migration `025` seeds period `1405`), `AccountingJournalPage`, `AccountingReportsPage`, `CafePurchasesPage`, `CafeReportsPage`, `TeachersPage`, and `SchedulePage`.
  4. **Server validation bug on partial period update:** In `server/src/routes/accountingPeriods.js:105, 122-126`, `PATCH /api/accounting/periods/:id` loads `start_date` and `end_date` (`Date` objects). If the request updates only `startDate` or only `endDate`, `next.startDate > next.endDate` compares a `Date` object against a `'YYYY-MM-DD'` string (which coerces the string to `NaN` and evaluates to `false`), bypassing the application-level check and falling through to the DB `CHECK (end_date >= start_date)` constraint (HTTP 500 instead of HTTP 400).
- **How to fix:**
  1. Register a custom type parser for `date` (OID `1082`) in both `server/src/db/pool.js` (`pg.types.setTypeParser(1082, (value) => value)`) and `server/src/db/pglite.js` (`parsers: { 1082: (value) => value }`) so PostgreSQL `date` columns always return `'YYYY-MM-DD'` strings across the entire application.
  2. Also harden `localDateFromIso(isoDate)` in `client/src/lib/locale.js:35-38` to slice `String(isoDate).slice(0, 10)` before splitting on `'-'`.

---

### 2. [Major] Closed fiscal period trigger exceptions during Cafe auto-posting and Opening Entry creation return unhandled `500 Internal Server Error`

- **Where:**
  - `server/src/lib/accountingJournal.js:219-223, 346-350`
  - `server/src/routes/cafeSales.js:32-49`
  - `server/src/routes/cafePurchases.js:201-218`
  - `server/src/routes/cafeBalances.js:88-107`
  - `server/src/routes/cafeInventory.js:161-198`
  - `server/src/routes/accountingPeriods.js:265-297`
- **Confirmed by:** Reading code + migration `025_create_accounting_core.sql` (`acct_entry_lifecycle` trigger).
- **Details:**
  - When a fiscal period is closed, the database trigger `acct_entry_lifecycle` (`025_create_accounting_core.sql:101-106`) raises `cannot post into a closed fiscal period (%)` whenever an entry is inserted or updated with `status = 'posted'` and an `entry_date` inside that closed period.
  - Only `POST /api/accounting/journal/:id/post` (`server/src/routes/accountingJournal.js:210-215`) catches `/closed fiscal period/` and translates it to `409 ACCOUNTING_PERIOD_CLOSED`.
  - `POST /api/accounting/periods/opening` (`server/src/routes/accountingPeriods.js:265-297`) and all four Cafe routes (`cafeSales`, `cafePurchases`, `cafeBalances`, `cafeInventory` — which call `postMappedEvent` with `status = 'posted'` inside their transaction) do not catch `/closed fiscal period/`, resulting in an unhandled `500 Internal Server Error` if the current date falls inside a closed fiscal period and accounting mappings are active.
- **How to fix:**
  - Catch `/closed fiscal period/` in `POST /api/accounting/periods/opening` and in the Cafe routes (or translate the trigger error inside `postMappedEvent` / `generateOpeningEntry` in `server/src/lib/accountingJournal.js` into a structured `{ error, code: 'ACCOUNTING_PERIOD_CLOSED', status: 409 }` error).

---

### 3. [Major] Audit log category filter mismatches emitted action prefixes for Cafe Inventory and Accounting

- **Where:**
  - `server/src/routes/audit.js:6-36, 60-61`
  - `server/src/routes/cafeInventory.js:181`
  - `server/src/lib/auditRules.js:27-32`
  - `server/src/routes/accountingJournal.js:138, 204, 244`
  - `server/src/core/services/audit.js:16-33`
  - `client/src/lib/audit.js:3-32`
- **Confirmed by:** Reading code.
- **Details:**
  - `GET /api/audit` filters categories via `split_part(a.action, '.', 1) = $n`.
  - In `server/src/routes/cafeInventory.js:181`, waste and adjustments are recorded with action `${kind === 'waste' ? 'cafe_waste' : 'cafe_adjustment'}.create`. However, `AUDIT_CATEGORIES` (`client/src/lib/audit.js:24`) only exposes `'cafe_inventory'`. Selecting **Cafe inventory** on the Audit page queries `split_part(a.action, '.', 1) = 'cafe_inventory'`, which never matches `cafe_waste.create` or `cafe_adjustment.create` (always returns 0 rows).
  - Similarly, `AUDIT_CATEGORIES` (`client/src/lib/audit.js:25`) only exposes `'accounting'` (alongside `'accounting_period'`). While `accounting.opening_balance` has prefix `'accounting'`, account changes emit `'accounting_account.*'`, mapping changes emit `'accounting_mapping.update'`, and journal entries emit `'accounting_entry.*'`. Filtering by **Accounting** on the Audit page misses all account, mapping, and journal entry actions.
  - Additionally, `server/src/core/services/audit.js:16-33` (used by the PGlite local build) has an outdated `CATEGORIES` array that is missing `task_template`, `evaluation`, `field_definition`, and all `cafe*`, `accounting*`, and `agent` categories.
- **How to fix:**
  - Expand category filtering in `server/src/routes/audit.js` and `server/src/core/services/audit.js` so that umbrella categories match their constituent prefixes (`cafe_inventory` -> `['cafe_inventory', 'cafe_waste', 'cafe_adjustment']`, `accounting` -> `['accounting', 'accounting_account', 'accounting_mapping', 'accounting_entry']`), and share a single category definition list with `server/src/lib/auditRules.js`.

---

### 4. [Major] Soft-deleted students' balances are still included in Cafe Reports debt totals and the Accounting Opening Entry snapshot

- **Where:**
  - `server/src/lib/cafeReports.js:68-73`
  - `server/src/lib/accountingJournal.js:256-261`
- **Confirmed by:** Reading code.
- **Details:**
  - When a student is soft-deleted (`students.deleted_at IS NOT NULL`), `GET /api/cafe/balances/students` (`server/src/routes/cafeBalances.js:37`) filters them out via `WHERE s.deleted_at IS NULL`.
  - However, `getRangeReport` (`server/src/lib/cafeReports.js:68-73`) computes `debtorsCount` and `totalDebt` across all rows in `student_balances WHERE balance < 0` without checking `students.deleted_at IS NULL`.
  - Likewise, `generateOpeningEntry` (`server/src/lib/accountingJournal.js:256-261`) sums `student_balances` for accounts `1110` (Student Advances Receivable) and `2110` (Student Prepayments) without excluding soft-deleted students.
- **How to fix:**
  - Join `students s ON s.id = sb.student_id WHERE s.deleted_at IS NULL` in both `server/src/lib/cafeReports.js` and `server/src/lib/accountingJournal.js`.

---

### 5. [Major] `resetData.js` wipes `acct_fiscal_periods` without re-seeding the default fiscal period

- **Where:** `server/src/scripts/resetData.js:72-116`
- **Confirmed by:** Reading code (`resetData.js` vs `025_create_accounting_core.sql:198-200`).
- **Details:**
  - Migration `025_create_accounting_core.sql` seeds the initial open fiscal period (`'1405'`, `'2026-03-21'` to `'2027-03-20'`) alongside the chart of accounts and default cafe-to-accounting mappings.
  - `resetData.js:82` truncates `acct_fiscal_periods`, and lines `97-116` re-seed `scheduling_intervals` and `acct_mappings`, but do not re-seed the default fiscal period. After running `npm run reset-data -- confirm`, no fiscal period exists until an accountant manually creates one, and any Cafe transaction (since mappings are re-seeded as `active = true`) will fail to auto-post unless a fiscal period is created or mappings are paused.
- **How to fix:**
  - Re-seed the default open fiscal period in `server/src/scripts/resetData.js` right after re-seeding `acct_mappings`.

---

### 6. [Minor] PGlite vs `pg` `interval` representation mismatch in `SchedulePage.jsx`

- **Where:**
  - `client/src/pages/SchedulePage.jsx:29-57` (`formatEvery`, `nextOccurrence`)
  - `server/src/db/pglite.js:52-59`
- **Confirmed by:** Runtime type-parser probe + reading code.
- **Details:**
  - `node-postgres` (`pg`) parses PostgreSQL `interval` columns (OID `1186`) into objects (`{ days: 7 }`, `{ months: 1 }`), which `SchedulePage.jsx` expects (`every.days`, `every.months`, `every.years`).
  - `@electric-sql/pglite` returns `interval` columns as raw PostgreSQL strings (`"7 days"`, `"1 mon"`). In a PGlite-backed build, `every` is a string, so `every.days` is `undefined`, `formatEvery` renders `'—'`, and `nextOccurrence` returns `null`.
- **How to fix:**
  - Either register an OID `1186` parser in `server/src/db/pglite.js` that returns `{ years, months, days }` objects matching `postgres-interval`, or add a small string-interval normalizer in `SchedulePage.jsx`.

---

### 7. [Minor] `server/src/scripts/seedSample.js` `removeSample()` can fail with FK constraint error if a sample student has Cafe history

- **Where:** `server/src/scripts/seedSample.js:237-247`
- **Confirmed by:** Reading code.
- **Details:**
  - `npm run seed-sample -- remove` runs `DELETE FROM students WHERE full_name LIKE 'Sample Student%'`.
  - If a developer used a sample student in the Cafe POS or Balances page during testing, `student_balances`, `student_balance_transactions`, or `cafe_sales` (`ON DELETE RESTRICT`) will reference that student, causing `removeSample()` to fail with a foreign key constraint violation.
- **How to fix:**
  - Either clean up dependent sample-student rows (or soft-delete sample students that have financial ledger rows) or catch `23503` (`foreign_key_violation`) and print a clear message explaining which sample students have immutable ledger rows.

---

### 8. [Minor] `deploy/backup.sh` pipeline can leave a truncated `.sql.gz` file on disk if `pg_dump` fails mid-stream

- **Where:** `deploy/backup.sh:30-31, 36-38`
- **Confirmed by:** Reading code.
- **Details:**
  - `pg_dump --no-owner --no-ACL "$DATABASE_URL" | gzip >"$OUT"` creates `"$OUT"` immediately. Even with `set -euo pipefail`, if `pg_dump` fails mid-stream (or cannot connect), a partial/empty `.sql.gz` file remains in `$BACKUP_DIR` with a `.sql.gz` extension. On subsequent runs, the rotation loop counts that corrupt file toward `$KEEP` (`30`) and can rotate out older valid backups.
- **How to fix:**
  - Write to `"$OUT.tmp"`, register `trap 'rm -f "$OUT.tmp"' EXIT`, verify `gzip -t "$OUT.tmp"`, and `mv "$OUT.tmp" "$OUT"` atomically before rotating old backups.

---

### 9. [Minor] `deploy/backup.sh` and `deploy/student-panel-backup.service` do not set a restrictive umask (`0077`)

- **Where:**
  - `deploy/backup.sh:25-31`
  - `deploy/student-panel-backup.service:14-18`
- **Confirmed by:** Reading code.
- **Details:**
  - While `deploy/student-panel.service` sets `UMask=0077` and hardening flags, `deploy/student-panel-backup.service` and `deploy/backup.sh` do not set a umask. Database dumps created in `/var/backups/student-panel` inherit the default `0022` umask (`0644` world-readable permissions unless the directory itself restricts traversal).
- **How to fix:**
  - Add `umask 077` at the top of `deploy/backup.sh` and `UMask=0077` / `NoNewPrivileges=true` in `deploy/student-panel-backup.service`.

---

### 10. [Cosmetic] `AuditPage` `describeAudit()` falls back to generic action title without interpolated entity details for newer Cafe and Accounting actions

- **Where:**
  - `client/src/pages/AuditPage.jsx:50-101`
  - `client/src/lib/audit.js:47-291`
- **Confirmed by:** Reading code.
- **Details:**
  - `describeAudit(entry)` builds rich, human-readable descriptions with interpolated parameters (`name`, `code`, `amount`, etc.) for pre-Cafe actions (`student.*`, `parameter.*`, `evaluation.*`, `user.*`, `role.*`, `group.*`, `field_definition.*`, `teacher.*`, `interval.*`, `assignment.*`, `session.*`, `task.*`, `task_template.*`, `alert.*`), but has no `case` branches for `cafe_*` or `accounting_*` actions.
  - Those actions hit `default: return [{ key: entry.action }]`, which translates the static label in `client/src/i18n/{fa,en}/audit.json` (e.g., `"Sale recorded"`, `"Journal entry posted"`) without showing the receipt/entry number, product name, student name, or Toman amount stored in `entry.details`.
- **How to fix:**
  - Add `case` branches in `describeAudit()` (`client/src/lib/audit.js`) and corresponding parameterized strings in `client/src/i18n/{fa,en}/audit.json` for `cafe_*` and `accounting_*` audit entries.

---

## Suggestions (Ordered by Value)

1. **[Quick Win] Centralize PostgreSQL `date` (OID `1082`) type parsing in `pool.js` and `pglite.js`:**
   Adding `pg.types.setTypeParser(1082, (v) => v)` in `server/src/db/pool.js` and `parsers: { 1082: (v) => v }` in `server/src/db/pglite.js` eliminates an entire class of `Date` vs `'YYYY-MM-DD'` serialization bugs across all routes (`sessions`, `accountingPeriods`, `accountingJournal`, `accountingReports`, `cafePurchases`, `cafeReports`, `teachers`, `assignments`, `alerts`) in ~6 lines of code.
2. **[Quick Win] Atomic backup writes and `umask 077` in `deploy/backup.sh`:**
   Writing to `"$OUT.tmp"` with a cleanup trap and `umask 077` guarantees that failed `pg_dump` runs never leave corrupt `.sql.gz` files or world-readable database dumps in `/var/backups/student-panel`.
3. **[Quick Win] Unify Audit Category mappings between `auditRules.js`, `routes/audit.js`, and `core/services/audit.js`:**
   Defining the category-to-action-prefix map in `server/src/lib/auditRules.js` and importing it in both `routes/audit.js` and `core/services/audit.js` prevents drift when new modules are added.
4. **[Larger Improvement] Consolidate Express routes (`server/src/routes/*`) and Local Core Services (`server/src/core/services/*`):**
   Currently, SQL queries and validation flows for `students`, `parameters`, `evaluations`, `groups`, `fields`, `users`, `roles`, `audit`, etc. are duplicated between `server/src/routes/` and `server/src/core/services/`, while newer modules (`teachers`, `intervals`, `assignments`, `sessions`, `tasks`, `alerts`, `cafe*`, `accounting*`) only exist in `server/src/routes/`. Sharing service functions between Express routes and the PGlite local adapter would cut duplicated SQL in half and bring the offline/Capacitor build to full feature parity.
5. **[Larger Improvement] Add an automated API serialization contract test for `date` and `interval` columns in `verify-pglite` / `test:core`:**
   Because unit tests mock `pool.query` with plain strings while real PostgreSQL/PGlite applies OID type parsers, adding a lightweight integration test in `test:core` that seeds a session, fiscal period, purchase, and journal entry and asserts `/^\d{4}-\d{2}-\d{2}$/` on returned date fields will catch any future type-parser regressions automatically.
